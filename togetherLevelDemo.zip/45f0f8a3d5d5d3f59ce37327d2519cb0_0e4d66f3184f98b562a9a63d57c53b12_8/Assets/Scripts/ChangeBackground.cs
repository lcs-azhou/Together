﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeBackground : MonoBehaviour
{
    public GameObject bg1;
    public GameObject bg2;

    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
    public void BackgroundChanger ()
    {
        bg1.SetActive(false);
        bg2.SetActive(true);

    }
}
